from .config import get_cfg

__all__ = [
    "get_cfg",
]
