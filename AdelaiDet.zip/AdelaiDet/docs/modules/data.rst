adet.data package
=======================

.. automodule:: adet.data
    :members:
    :undoc-members:
    :show-inheritance: